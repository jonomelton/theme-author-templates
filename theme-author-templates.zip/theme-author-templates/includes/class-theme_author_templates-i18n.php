<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://demo.funnelandclick.com/
 * @since      1.0.0
 *
 * @package    Theme_author_templates
 * @subpackage Theme_author_templates/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Theme_author_templates
 * @subpackage Theme_author_templates/includes
 * @author     Jonathan Power <hello@funnelandclick.com>
 */
class Theme_author_templates_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'theme_author_templates',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
