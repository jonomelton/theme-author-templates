<?php

/**
 * Fired during plugin activation
 *
 * @link       https://demo.funnelandclick.com/
 * @since      1.0.0
 *
 * @package    Theme_author_templates
 * @subpackage Theme_author_templates/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Theme_author_templates
 * @subpackage Theme_author_templates/includes
 * @author     Jonathan Power <hello@funnelandclick.com>
 */
class Theme_author_templates_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
