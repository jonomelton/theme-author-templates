<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://demo.funnelandclick.com/
 * @since      1.0.0
 *
 * @package    Theme_author_templates
 * @subpackage Theme_author_templates/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Theme_author_templates
 * @subpackage Theme_author_templates/includes
 * @author     Jonathan Power <hello@funnelandclick.com>
 */
class Theme_author_templates_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
